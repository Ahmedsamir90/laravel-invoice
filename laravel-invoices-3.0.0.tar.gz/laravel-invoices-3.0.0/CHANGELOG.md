# Changelog

All notable changes to `laraveldaily/invoices` will be documented in this file.

## Version 1.3.8

### Added
- Shipping method ->shipping(float $amount), translation for template
