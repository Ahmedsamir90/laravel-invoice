<?php

namespace LaravelDaily\Invoices\Classes;

/**
 * Class Buyer
 * @package LaravelDaily\Invoices\Classes
 */
class Buyer extends Party
{
}
